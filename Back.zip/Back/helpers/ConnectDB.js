const mongoose = require ('mongoose')
require('dotenv').config()

const ConnectDB = () => {
    mongoose.connect(process.env.MONGO_URI, (err) => {
        if (err) {
            throw err
        }
        console.log("Database connected...")
    })
}


module.exports = ConnectDB;